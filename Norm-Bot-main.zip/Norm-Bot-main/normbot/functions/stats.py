import asyncio
import os
import subprocess
import time

import psutil
from pyrogram import filters

bot_start_time = time.time()
from normbot import normversion

def get_readable_time(seconds: int) -> str:
    count = 0
    ping_time = ""
    time_list = []
    time_suffix_list = ["s", "m", "h", "days"]
    while count < 4:
        count += 1
        if count < 3:
            remainder, result = divmod(seconds, 60)
        else:
            remainder, result = divmod(seconds, 24)
        if seconds == 0 and remainder == 0:
            break
        time_list.append(int(result))
        seconds = int(remainder)
    for i in range(len(time_list)):
        time_list[i] = str(time_list[i]) + time_suffix_list[i]
    if len(time_list) == 4:
        ping_time += time_list.pop() + ", "
    time_list.reverse()
    ping_time += ":".join(time_list)
    return ping_time

async def bot_sys_stats():
    bot_uptime = int(time.time() - bot_start_time)
    cpu = psutil.cpu_percent()
    mem = psutil.virtual_memory().percent
    disk = psutil.disk_usage("/").percent
    process = psutil.Process(os.getpid())
    stats = f"""

Norm
------------------
Version: {normversion} (Latest)
Uptime : {get_readable_time((bot_uptime))}
Bot    : {round(process.memory_info()[0] / 1024 ** 2)} MB
CPU    : {cpu}%
Ram    : {mem}%
Disk   : {disk}%

root@TinuraD
"""
    return stats
