moretooltext = f"""
** GPS **
 • /gps <හොයන්න ඕන තැන>  - අපි දෙන තැන Map එක බලන්න.
 
 ** Send **
 • /send <message> : Bot ගෙන් message දාන්න.
 • /edit <reply to media> : File එකක media edit කරන්න.
 
** Grammer **
 • /t <reply> : Grammer හරි ගස්සන්න
 
** Image Tools**
 • /img <ඕන image එක search කරන්න>: Photo කරන්න
 • /getqr <photo එකකට reply කරන්න >: Photo එකට QR code එකක් හදන්න
 • /makeqr <Link එක දෙන්න>: Make QR code එකක් හදන්න.
 
** Text Style කරන්න **
 • /weebify : Weebify Text
 • /square : square Text
 • /blue : Blues text
"""
