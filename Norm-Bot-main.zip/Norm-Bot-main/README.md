# Norm 🤖 - Telegram Bot
- Python Telegram Bot based group manager telegram bot.
- Stoppet Project. But this source code was working when updating this file.
- This is a cloned and modified version of [Daisy-Old Bot](https://github.com/TeamDaisyX/Daisy-OLD).

## Features
- Main group managment features.
- Anit-spam mode.
- Some parts in Sinhala language 🇱🇰.
- Filters Support.
- And more features

## Deploy your own bot here.
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/TinuraD/Norm.git)
## Credits

- This bot besed on [TG Bot](https://github.com/PaulSonOfLars/tgbot) which made by [Paul Larsen](https://github.com/PaulSonOfLars). So oiginal credits go to [PaulSonOfLars](https://github.com/PaulSonOfLars) and his dedication. And Norm was cloned by [Daisy-Old Bot](https://github.com/TeamDaisyX/Daisy-OLD), so credits also goes to [Team DaisyX](https://github.com/TeamDaisyX/).

### Other Credits
 - DaisyBot
 - Saitma Robot
 - William Butcher Bot
 - TeamDaisyX
 - Telethon
 - Pyrogram
 - MaxRobot
 - SZ Rose Bot
 - SL Bot Zone
